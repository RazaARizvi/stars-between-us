# Fonts for a venue without internet

By default the fonts come from Google Fonts, which needs internet. If the screen or iPad has no internet at the venue, the text falls back to a system font and looks different.

To work offline:
1. Download your chosen fonts (for example from fonts.google.com, button "Download family") on a computer with internet.
2. Put the `.woff2` files in this folder.
3. In `public/css/app.css`, delete the `@import` line and add, for each font:
   `@font-face { font-family: 'Name'; src: url('../fonts/file.woff2') format('woff2'); font-weight: 400 600; font-display: swap; }`
4. Check `--display` and `--mono` in the same file use the same names.
5. Open the page with the Wi-Fi turned off and see that the font is still there.
