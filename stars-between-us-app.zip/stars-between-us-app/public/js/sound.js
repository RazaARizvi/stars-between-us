/* sound.js: the sound of the sky, in the browser (Web Audio). window.StarSound.

   WHAT IS FIXED
   - Each of the six colours has one tone (TONES). Placeholder: the six notes of a whole-tone
     scale on F, Warmth lowest, Company highest. The melody colleague replaces them with setTones()
     or by editing TONES below.
   - A new star plays the tones of its colours, lowest to highest, like a short chime.
   - Quiet background notes keep the sky alive between stars.

   WHAT IS STILL OPEN: how a repeated colour should change the sound. Two rules are built so the
   team can listen and decide. On the screen page, press 1 or 2 to switch.
     'presence'  The more a colour appears in the whole sky, the more present its tone is: louder
                 in each chime, picked more often by the background notes, and it carries a low
                 hum. The colour in the majority sets the mood of the sky.
     'layers'    A colour repeated inside ONE star adds layers to its tone: an octave higher,
                 then a fifth higher, then a quick octave. The sky itself stays equal.
   Loudness is kept the same either way: richer, not louder.

   AUDIO FILES: drop files into public/sounds/ named after the colour (red.wav, yellow.wav, blue.wav,
   green.wav, purple.wav, orange.wav) and/or base.wav (a loop that plays under everything). A colour
   with a file plays that file instead of the browser tone; a repeated colour plays it again at a higher
   pitch (octave, fifth). Colours without a file keep the browser tone. See public/sounds/README.md.   */
(function (root) {
  'use strict';

  var KEYS = ['red', 'yellow', 'blue', 'green', 'purple', 'orange'];
  var BASE = 174.61 * 2, SEMIS = [0, 2, 4, 6, 8, 10];            // whole-tone scale on F, one octave up
  var TONES = {};
  KEYS.forEach(function (k, i) { TONES[k] = BASE * Math.pow(2, SEMIS[i] / 12); });

  var rule = 'presence', vol = 0.5, ctx = null, master = null, hum = null, active = 0, MAX_ACTIVE = 60, ambientTimer = null;
  var samples = {}, baseNode = null, sampleLoad = null, BASE_GAIN = 0.3;

  function setTones(t) { Object.keys(t).forEach(function (k) { if (KEYS.indexOf(k) >= 0 && t[k] > 0) TONES[k] = t[k]; }); }
  function setRule(r) { if (r === 'presence' || r === 'layers') rule = r; return rule; }
  function getRule() { return rule; }
  function setVolume(v) { vol = Math.max(0, Math.min(1, v)); if (master) master.gain.value = vol * 0.7; }
  function isRunning() { return !!ctx && ctx.state === 'running'; }

  // Call from a tap or click: browsers do not allow sound before that.
  function unlock() {
    if (!ctx) {
      var AC = root.AudioContext || root.webkitAudioContext;
      if (!AC) return false;
      ctx = new AC();
      var comp = ctx.createDynamicsCompressor();                  // a limiter, to protect speakers and ears
      comp.threshold.value = -20; comp.knee.value = 18; comp.ratio.value = 10; comp.attack.value = 0.004; comp.release.value = 0.25;
      master = ctx.createGain(); master.gain.value = vol * 0.7;
      master.connect(comp); comp.connect(ctx.destination);
    }
    if (ctx.state === 'suspended') ctx.resume();
    if (!sampleLoad) sampleLoad = loadSamples();
    return true;
  }

  /* ---------- audio files from public/sounds ---------- */
  function loadSamples() {
    var getList = fetch('/api/sounds').then(function (r) { return r.ok ? r.json() : Promise.reject(); })
      .catch(function () { return fetch('sounds/manifest.json').then(function (r) { return r.ok ? r.json() : { files: {} }; }); })
      .catch(function () { return { files: {} }; });
    return getList.then(function (m) {
      var files = (m && m.files) || {};
      return Promise.all(Object.keys(files).filter(function (n) { return n === 'base' || KEYS.indexOf(n) >= 0; }).map(function (name) {
        return fetch(files[name]).then(function (r) { return r.arrayBuffer(); })
          .then(function (buf) { return new Promise(function (ok, no) { ctx.decodeAudioData(buf, ok, no); }); })
          .then(function (b) { samples[name] = b; }).catch(function () { /* a broken file is skipped */ });
      }));
    }).then(startBase);
  }
  function startBase() {
    if (!samples.base || baseNode || !ctx) return;
    var src = ctx.createBufferSource(), g = ctx.createGain();
    src.buffer = samples.base; src.loop = true; g.gain.value = BASE_GAIN;
    src.connect(g); g.connect(master); src.start(); baseNode = src;
  }
  function loaded() { return Object.keys(samples); }
  function sample(name, rate, when, peak) {
    if (!isRunning() || active >= MAX_ACTIVE) return;
    active++;
    var t = ctx.currentTime + 0.02 + (when || 0), s = ctx.createBufferSource(), g = ctx.createGain();
    s.buffer = samples[name]; s.playbackRate.value = rate; g.gain.value = Math.min(1, peak * 4);
    s.connect(g); g.connect(master); s.start(t); s.onended = function () { active--; };
  }
  // One voice of a colour: its audio file if there is one, otherwise the browser tone. rate 2 = an octave up.
  function voice(k, rate, when, peak, decay) {
    if (samples[k]) sample(k, rate, when, peak); else bell(TONES[k] * rate, when, peak, decay);
  }

  // One soft bell: a sine and its octave, fast attack, slow fade.
  function bell(freq, when, peak, decay) {
    if (!isRunning() || active >= MAX_ACTIVE) return;
    active++;
    var t = ctx.currentTime + 0.02 + (when || 0);
    var o = ctx.createOscillator(), o2 = ctx.createOscillator(), e = ctx.createGain(), m = ctx.createGain();
    o.type = 'sine'; o.frequency.value = freq; o2.type = 'sine'; o2.frequency.value = freq * 2; m.gain.value = 0.22;
    o2.connect(m); m.connect(e); o.connect(e); e.connect(master);
    e.gain.setValueAtTime(0.0001, t);
    e.gain.linearRampToValueAtTime(peak, t + 0.015);
    e.gain.exponentialRampToValueAtTime(0.0001, t + decay);
    o.start(t); o2.start(t); o.stop(t + decay + 0.05); o2.stop(t + decay + 0.05);
    o.onended = function () { active--; };
  }

  function counts(sky) { return root.StarsLib.skyCounts(sky, KEYS); }
  function maxOf(c) { return Math.max(1, Math.max.apply(null, KEYS.map(function (k) { return c[k]; }))); }

  // The chime of one star. `sky` = every star in the sky, including this one.
  function playStar(star, sky, opts) {
    if (!isRunning() || !star) return false;
    var scale = (opts && opts.gain) || 1;
    var inStar = {}, distinct = [];
    star.colours.forEach(function (k) { if (!inStar[k]) { inStar[k] = 0; distinct.push(k); } inStar[k]++; });
    distinct.sort(function (a, b) { return KEYS.indexOf(a) - KEYS.indexOf(b); });
    var c = counts(sky || [star]), top = maxOf(c), step = 0.26;
    var voices = 0;
    distinct.forEach(function (k) { voices += rule === 'layers' ? Math.min(4, inStar[k]) : 1; });
    var norm = 0.2 / Math.sqrt(Math.max(1, voices));                // same loudness, however many voices

    distinct.forEach(function (k, i) {
      var n = inStar[k], t = i * step;
      if (rule === 'layers') {
        voice(k, 1, t, norm * scale, 1.8);
        if (n >= 2) voice(k, 2, t + 0.12, norm * 0.6 * scale, 1.6);
        if (n >= 3) voice(k, 1.5, t + 0.06, norm * 0.5 * scale, 1.6);
        if (n >= 4) { voice(k, 2, t + 0.18, norm * 0.4 * scale, 0.9); voice(k, 2, t + 0.30, norm * 0.4 * scale, 0.9); }
      } else {
        var share = c[k] / top;                                      // 1 = the most common colour in the sky
        voice(k, 1, t, norm * (0.5 + 1.0 * share) * (1 + 0.15 * (n - 1)) * scale, 1.5 + 0.9 * share);
      }
    });
    updateHum(sky);
    return true;
  }

  // 'presence': a low, quiet hum on the tone of the colour that is in the majority.
  function updateHum(sky) {
    if (!isRunning()) return;
    if (!hum) {
      var a = ctx.createOscillator(), b = ctx.createOscillator(), g = ctx.createGain();
      a.type = 'sine'; b.type = 'sine'; b.detune.value = 4; g.gain.value = 0;
      a.connect(g); b.connect(g); g.connect(master); a.start(); b.start();
      hum = { a: a, b: b, g: g };
    }
    var c = counts(sky || []), top = maxOf(c), best = KEYS[0];
    KEYS.forEach(function (k) { if (c[k] > c[best]) best = k; });
    var has = c[best] > 0, share = c[best] / top, t = ctx.currentTime;
    var f = TONES[best] / 2;
    hum.a.frequency.setTargetAtTime(f, t, 1.5); hum.b.frequency.setTargetAtTime(f, t, 1.5);
    hum.g.gain.setTargetAtTime(rule === 'presence' && has ? 0.02 + 0.03 * share : 0, t, 1.2);
  }

  // Quiet notes between stars. getSky() returns the stars now in the sky.
  function startAmbient(getSky, onPing) {
    stopAmbient();
    (function tick() {
      var sky = getSky();
      if (isRunning() && sky.length && !root.document.hidden) {
        if (rule === 'presence') {
          var c = counts(sky), top = maxOf(c), total = 0, r, pick = KEYS[0];
          KEYS.forEach(function (k) { total += c[k]; });
          r = Math.random() * total;
          for (var i = 0; i < KEYS.length; i++) { r -= c[KEYS[i]]; if (r <= 0) { pick = KEYS[i]; break; } }
          voice(pick, Math.random() < 0.35 ? 2 : 1, 0, 0.03 + 0.05 * (c[pick] / top), 2.4);
        } else {
          var s = sky[Math.floor(Math.random() * sky.length)];
          playStar(s, sky, { gain: 0.3 });
          if (onPing) onPing(s);
        }
      }
      ambientTimer = setTimeout(tick, 1800 + Math.random() * 1600);
    })();
  }
  function stopAmbient() { if (ambientTimer) clearTimeout(ambientTimer); ambientTimer = null; }

  root.StarSound = {
    KEYS: KEYS, TONES: TONES, setTones: setTones, setRule: setRule, getRule: getRule, setVolume: setVolume,
    unlock: unlock, isRunning: isRunning, loaded: loaded, playStar: playStar, startAmbient: startAmbient, stopAmbient: stopAmbient, updateHum: updateHum
  };
})(window);
