/* stars-lib.js: the rules for a star, shared by the server and the pages.
   Browser: window.StarsLib. Node: require('./public/js/stars-lib.js').
   A star: { id, colours: ['red','blue','red'], x: 0..1, y: 0..1, linkedTo: id | null, timestamp } */
(function (root) {
  'use strict';
  var DEFAULT_KEYS = ['red', 'yellow', 'blue', 'green', 'purple', 'orange'];
  var clamp01 = function (n) { return Math.min(1, Math.max(0, Number(n))); };

  // Check what the iPad sends. Bad input never enters the sky.
  // o = { validKeys, stars (the sky so far), id, now }
  function makeStar(input, o) {
    o = o || {};
    var keys = o.validKeys || DEFAULT_KEYS;
    if (!input || !Array.isArray(input.colours)) return null;
    var colours = input.colours.filter(function (c) { return keys.indexOf(c) >= 0; }).slice(0, 4);   // at most four colours
    if (colours.length < 1) return null;
    if (input.x == null || input.y == null || isNaN(Number(input.x)) || isNaN(Number(input.y))) return null;
    var stars = o.stars || [];
    var linkedTo = null;
    if (typeof input.linkedTo === 'string') {
      for (var i = 0; i < stars.length; i++) if (stars[i].id === input.linkedTo) { linkedTo = input.linkedTo; break; }
    }
    return { id: o.id, colours: colours, x: clamp01(input.x), y: clamp01(input.y), linkedTo: linkedTo, timestamp: o.now || Date.now() };
  }

  function sharedColours(a, b) {
    var out = [];
    (a.colours || []).forEach(function (c) {
      if ((b.colours || []).indexOf(c) >= 0 && out.indexOf(c) < 0) out.push(c);
    });
    return out;
  }

  // Stars the group could join, best first: most shared colours, then nearest.
  function rankLinks(star, others) {
    return (others || []).filter(function (o) { return o.id !== star.id; })
      .map(function (o) { return { o: o, n: sharedColours(star, o).length, d: Math.hypot(o.x - star.x, o.y - star.y) }; })
      .sort(function (a, b) { return b.n - a.n || a.d - b.d; })
      .map(function (r) { return r.o; });
  }

  // How often each colour appears in the whole sky (a colour repeated inside one star counts each time).
  function skyCounts(stars, keys) {
    var out = {};
    (keys || DEFAULT_KEYS).forEach(function (k) { out[k] = 0; });
    (stars || []).forEach(function (s) { (s.colours || []).forEach(function (c) { if (c in out) out[c]++; }); });
    return out;
  }

  var api = { DEFAULT_KEYS: DEFAULT_KEYS, makeStar: makeStar, sharedColours: sharedColours, rankLinks: rankLinks, skyCounts: skyCounts };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  else root.StarsLib = api;
})(typeof window !== 'undefined' ? window : this);
