/* net.js: one way to talk to the sky, with or without the server.
   Stars.connect({ init(stars), added(star), status(text) }) -> { mode: 'server' | 'demo', add(data) }

   server: Socket.IO (events stars:init, star:added, star:add), the real workshop mode.
   demo:   no server found (for example the files opened directly). Stars are kept in this browser
           and shared between tabs of the same browser, so the iPad and the screen can be tried
           side by side on one computer. */
(function (root) {
  'use strict';
  function connect(h) {
    var api = { mode: 'demo', add: null };
    if (typeof root.io === 'function') {
      var s = root.io();
      api.mode = 'server';
      s.on('stars:init', function (all) { h.init(all || []); });
      s.on('star:added', function (star) { h.added(star); });
      s.on('connect', function () { if (h.status) h.status('online'); });
      s.on('disconnect', function () { if (h.status) h.status('offline'); });
      api.add = function (data) { s.emit('star:add', data); };
      return api;
    }
    var KEY = 'stars-between-us-demo';
    var bc = typeof BroadcastChannel === 'function' ? new BroadcastChannel(KEY) : null;
    var load = function () { try { return JSON.parse(root.localStorage.getItem(KEY)) || []; } catch (e) { return []; } };
    var save = function (list) { try { root.localStorage.setItem(KEY, JSON.stringify(list)); } catch (e) { /* private window: stays in memory only */ } };
    var stars = load();
    setTimeout(function () { h.init(stars.slice()); if (h.status) h.status('demo'); }, 0);
    api.add = function (data) {
      var star = root.StarsLib.makeStar(data, { stars: stars, id: 'd' + Math.random().toString(36).slice(2, 10), now: Date.now() });
      if (!star) return;
      stars.push(star); save(stars);
      if (bc) bc.postMessage(star);
      h.added(star);
    };
    if (bc) bc.onmessage = function (e) {
      var star = e.data;
      if (!star || stars.some(function (x) { return x.id === star.id; })) return;
      stars.push(star); h.added(star);
    };
    return api;
  }
  root.StarsNet = { connect: connect };
})(window);
