/* common.js: colours, questions, and the sky drawing, used by the iPad and the screen.
   window.Stars = { colours(), colour(key), QUESTIONS, loadColours(), createSky(canvas, opts) }

   createSky() is the sky renderer. It is deliberately one small interface, so the design
   colleague's sky can replace it without touching the rest:
     sky.setStars(list)            the whole sky, no animation
     sky.addStar(star)             one new star grows in (star.linkedTo = id of the star it joins)
     sky.pulse(id)                 a star glows (when it sounds)
     sky.setPending(p | null)      the star being placed: { x, y, colours }
     sky.setSuggestion(id | null)  dashed line + ring to the star we suggest joining
     sky.setSelected(id | null)    ring around the star the group chose
     sky.hit(clientX, clientY)     star under a finger, or null
     sky.toNorm(clientX, clientY)  finger position as { x, y } from 0 to 1
     sky.fit()  sky.start()  sky.stars()                                                        */
(function (root) {
  'use strict';

  var COLOURS = [
    { key: 'red',    hex: '#ff6b5e', en: 'Warmth',  de: 'Wärme' },
    { key: 'yellow', hex: '#ffd45e', en: 'Light',   de: 'Licht' },
    { key: 'blue',   hex: '#5e9bff', en: 'Calm',    de: 'Ruhe' },
    { key: 'green',  hex: '#5ee08f', en: 'Growth',  de: 'Wachsen' },
    { key: 'purple', hex: '#b17bff', en: 'Memory',  de: 'Erinnerung' },
    { key: 'orange', hex: '#ff9a4d', en: 'Company', de: 'Gesellschaft' }
  ];
  var byKey = {};
  var index = function () { byKey = {}; COLOURS.forEach(function (c) { byKey[c.key] = c; }); };
  index();

  // The four cards. German wording still needs a native check.
  var QUESTIONS = [
    { tag: 'For you',          tagDe: 'Für dich',           en: 'What do you need this winter?',                  de: 'Was brauchst du in diesem Winter?' },
    { tag: 'For someone else', tagDe: 'Für jemand anderen', en: "What would you give to someone you don't know?", de: 'Was würdest du jemandem schenken, den du nicht kennst?' },
    { tag: 'For this place',   tagDe: 'Für diesen Ort',     en: 'What would you like to keep here?',              de: 'Was möchtest du hier bewahren?' },
    { tag: 'For later',        tagDe: 'Für später',         en: 'What do you hope for next spring?',              de: 'Was erhoffst du dir vom nächsten Frühling?' }
  ];

  // If the server is there, its config/colours.js wins, so there is one source of truth.
  function loadColours() {
    return fetch('/api/colours').then(function (r) { return r.ok ? r.json() : Promise.reject(); }).then(function (list) {
      if (Array.isArray(list) && list.length && list.every(function (c) { return c && c.key && c.hex; })) { COLOURS = list; index(); }
    }).catch(function () { /* demo mode: keep the built-in colours */ });
  }

  var hexA = function (h, a) { var n = parseInt(h.slice(1), 16); return 'rgba(' + (n >> 16) + ',' + ((n >> 8) & 255) + ',' + (n & 255) + ',' + a + ')'; };
  var easeOut = function (t) { return 1 - Math.pow(1 - t, 3); };

  // Eight points (the Fröbel star), each strip colour taking its turn.
  function drawStar(c, cx, cy, R, hexes, rot) {
    var inner = R * 0.42, n = hexes.length;
    for (var i = 0; i < 8; i++) {
      var a0 = (i - 0.5) * Math.PI / 4 + (rot || 0), a1 = i * Math.PI / 4 + (rot || 0), a2 = (i + 0.5) * Math.PI / 4 + (rot || 0);
      c.beginPath();
      c.moveTo(cx, cy);
      c.lineTo(cx + Math.sin(a0) * inner, cy - Math.cos(a0) * inner);
      c.lineTo(cx + Math.sin(a1) * R, cy - Math.cos(a1) * R);
      c.lineTo(cx + Math.sin(a2) * inner, cy - Math.cos(a2) * inner);
      c.closePath();
      c.fillStyle = hexes[i % n];
      c.fill();
      c.strokeStyle = 'rgba(8,12,25,.85)';
      c.lineWidth = 0.7;
      c.stroke();
    }
  }
  var hexesOf = function (s) { return s.colours.map(function (k) { return (byKey[k] || COLOURS[0]).hex; }); };

  function createSky(canvas, opts) {
    opts = opts || {};
    var g = canvas.getContext('2d');
    var W = 1, H = 1, DPR = 1, list = [], idx = {}, pending = null, suggestId = null, selectedId = null, started = false;
    var REDUCE = root.matchMedia && root.matchMedia('(prefers-reduced-motion: reduce)').matches;
    var dust = [];
    for (var i = 0; i < 130; i++) dust.push({ x: Math.random(), y: Math.random(), r: 0.4 + Math.random() * 0.9, p: Math.random() * 6.28 });

    var K = function () { return Math.max(0.8, Math.min(2.4, Math.min(W, H) / 620)) * (opts.scale || 1); };
    var margin = function () { return 44 * K(); };
    var px = function (s) { var m = margin(); return { x: m + s.x * (W - 2 * m), y: m + s.y * (H - 2 * m) }; };
    var radius = function (s) { return (14 + s.colours.length * 3) * K(); };

    function fit() {
      var r = canvas.getBoundingClientRect();
      DPR = Math.min(root.devicePixelRatio || 1, 2);
      W = Math.max(1, r.width); H = Math.max(1, r.height);
      canvas.width = Math.round(W * DPR); canvas.height = Math.round(H * DPR);
      g.setTransform(DPR, 0, 0, DPR, 0, 0);
    }
    function reindex() { idx = {}; list.forEach(function (s) { idx[s.id] = s; }); }
    function wrap(s, fresh) { return { id: s.id, colours: s.colours, x: s.x, y: s.y, linkedTo: s.linkedTo || null, born: fresh ? performance.now() : -1e9, pulse: -1e9 }; }

    function frame(now) {
      g.fillStyle = '#080c19'; g.fillRect(0, 0, W, H);
      dust.forEach(function (p) {
        var a = REDUCE ? 0.3 : 0.18 + 0.2 * Math.sin(now / 2600 + p.p * 5);
        g.fillStyle = 'rgba(190,205,255,' + Math.max(0.05, a) + ')';
        g.beginPath(); g.arc(p.x * W, p.y * H, p.r * K(), 0, 6.283); g.fill();
      });

      // lines: a star to the star it joined
      list.forEach(function (s) {
        var t = s.linkedTo && idx[s.linkedTo]; if (!t) return;
        var a = px(s), b = px(t), p = REDUCE ? 1 : Math.min(1, (now - s.born) / 1100);
        var gr = g.createLinearGradient(a.x, a.y, b.x, b.y);
        gr.addColorStop(0, hexA(hexesOf(s)[0], 0.65)); gr.addColorStop(1, hexA(hexesOf(t)[0], 0.65));
        g.strokeStyle = gr; g.lineWidth = Math.max(1, K());
        g.beginPath(); g.moveTo(a.x, a.y); g.lineTo(a.x + (b.x - a.x) * p, a.y + (b.y - a.y) * p); g.stroke();
      });

      // suggestion: dashed line from the star being placed to the suggested star
      if (suggestId && idx[suggestId] && pending) {
        var sp = px(pending), tp = px(idx[suggestId]);
        g.strokeStyle = 'rgba(211,226,255,.8)'; g.lineWidth = Math.max(1.2, K()); g.setLineDash([5 * K(), 7 * K()]);
        g.beginPath(); g.moveTo(sp.x, sp.y); g.lineTo(tp.x, tp.y); g.stroke(); g.setLineDash([]);
        g.beginPath(); g.arc(tp.x, tp.y, radius(idx[suggestId]) * 2.1, 0, 6.283); g.stroke();
      }

      list.forEach(function (s) {
        var p = px(s), age = now - s.born, grow = REDUCE || age > 800 ? 1 : easeOut(Math.max(0, age) / 800);
        var pulse = Math.max(0, 1 - (now - s.pulse) / 1600), R = radius(s) * grow;
        var hx = hexesOf(s), hr = Math.max(1, R * (2.5 + pulse * 2.5));
        var tw = REDUCE ? 0 : 0.06 * Math.sin(now / 900 + s.x * 17);
        var gr = g.createRadialGradient(p.x, p.y, 0, p.x, p.y, hr);
        gr.addColorStop(0, hexA(hx[0], Math.max(0, 0.22 + tw + pulse * 0.35))); gr.addColorStop(1, hexA(hx[0], 0));
        g.fillStyle = gr; g.beginPath(); g.arc(p.x, p.y, hr, 0, 6.283); g.fill();
        drawStar(g, p.x, p.y, R * (1 + pulse * 0.18), hx, 0);
        if (s.id === selectedId) { g.strokeStyle = 'rgba(211,226,255,.9)'; g.lineWidth = Math.max(1.5, K() * 1.5); g.beginPath(); g.arc(p.x, p.y, R * 1.9, 0, 6.283); g.stroke(); }
      });

      if (pending) {   // the star being placed
        var q = px(pending), R2 = (14 + pending.colours.length * 3) * K() * 1.15;
        var beat = REDUCE ? 0 : 0.5 + 0.5 * Math.sin(now / 350);
        g.save(); g.globalAlpha = 0.92;
        drawStar(g, q.x, q.y, R2, pending.colours.map(function (k) { return (byKey[k] || COLOURS[0]).hex; }), 0);
        g.restore();
        g.strokeStyle = 'rgba(232,236,248,' + (0.55 + 0.35 * beat) + ')'; g.lineWidth = Math.max(1.5, K() * 1.5); g.setLineDash([4 * K(), 6 * K()]);
        g.beginPath(); g.arc(q.x, q.y, R2 * (1.7 + 0.2 * beat), 0, 6.283); g.stroke(); g.setLineDash([]);
      }
      requestAnimationFrame(frame);
    }

    var sky = {
      fit: fit,
      start: function () { if (started) return; started = true; fit(); if (root.ResizeObserver) new ResizeObserver(fit).observe(canvas); requestAnimationFrame(frame); },
      stars: function () { return list; },
      setStars: function (all) { list = (all || []).map(function (s) { return wrap(s, false); }); reindex(); },
      addStar: function (s) { if (idx[s.id]) return; var w = wrap(s, true); list.push(w); idx[w.id] = w; },
      pulse: function (id) { if (idx[id]) idx[id].pulse = performance.now(); },
      setPending: function (p) { pending = p; },
      setSuggestion: function (id) { suggestId = id; },
      setSelected: function (id) { selectedId = id; },
      hit: function (cx, cy) {
        var r = canvas.getBoundingClientRect(), x = cx - r.left, y = cy - r.top, best = null, bd = 1e9;
        list.forEach(function (s) { var p = px(s), d = Math.hypot(p.x - x, p.y - y); if (d < Math.max(30, radius(s) * 2.2) && d < bd) { bd = d; best = s; } });
        return best;
      },
      toNorm: function (cx, cy) {
        var r = canvas.getBoundingClientRect(), m = margin();
        var nx = (cx - r.left - m) / Math.max(1, W - 2 * m), ny = (cy - r.top - m) / Math.max(1, H - 2 * m);
        return { x: Math.min(1, Math.max(0, nx)), y: Math.min(1, Math.max(0, ny)) };
      }
    };
    return sky;
  }

  root.Stars = {
    colours: function () { return COLOURS; },
    colour: function (k) { return byKey[k]; },
    QUESTIONS: QUESTIONS, loadColours: loadColours, createSky: createSky, drawStar: drawStar, hexesOf: hexesOf
  };
})(window);
