const { test } = require('node:test');
const assert = require('node:assert/strict');
const L = require('../public/js/stars-lib.js');

const sky = [
  { id: 'a', colours: ['red', 'blue'], x: 0.1, y: 0.1 },
  { id: 'b', colours: ['green'], x: 0.5, y: 0.5 },
  { id: 'c', colours: ['red', 'blue', 'green'], x: 0.9, y: 0.9 }
];

test('makeStar keeps at most four valid colours and clamps the position', () => {
  const s = L.makeStar({ colours: ['red', 'nope', 'blue', 'red', 'green', 'purple', 'orange'], x: 1.4, y: -2 }, { stars: [], id: 'x', now: 5 });
  assert.deepEqual(s.colours, ['red', 'blue', 'red', 'green']);
  assert.equal(s.x, 1); assert.equal(s.y, 0); assert.equal(s.linkedTo, null); assert.equal(s.timestamp, 5);
});
test('makeStar rejects bad input', () => {
  assert.equal(L.makeStar(null, {}), null);
  assert.equal(L.makeStar({ colours: ['pink'], x: 0.5, y: 0.5 }, {}), null);   // no valid colour
  assert.equal(L.makeStar({ colours: ['red'], x: 'a', y: 0.5 }, {}), null);
  assert.equal(L.makeStar({ colours: ['red'], y: 0.5 }, {}), null);             // missing x
});
test('linkedTo must be a star that exists', () => {
  assert.equal(L.makeStar({ colours: ['red'], x: 0.2, y: 0.2, linkedTo: 'b' }, { stars: sky, id: 'n' }).linkedTo, 'b');
  assert.equal(L.makeStar({ colours: ['red'], x: 0.2, y: 0.2, linkedTo: 'zzz' }, { stars: sky, id: 'n' }).linkedTo, null);
  assert.equal(L.makeStar({ colours: ['red'], x: 0.2, y: 0.2, linkedTo: 42 }, { stars: sky, id: 'n' }).linkedTo, null);
});
test('rankLinks: most shared colours first, then nearest', () => {
  const me = { id: 'n', colours: ['red', 'blue'], x: 0.2, y: 0.2 };
  assert.deepEqual(L.rankLinks(me, sky).map((s) => s.id), ['a', 'c', 'b']);       // a and c share 2; a is nearer
  assert.deepEqual(L.rankLinks(me, []), []);
});
test('skyCounts counts a repeated colour every time', () => {
  const c = L.skyCounts([{ colours: ['red', 'red', 'blue'] }, { colours: ['red'] }]);
  assert.equal(c.red, 3); assert.equal(c.blue, 1); assert.equal(c.green, 0);
});
