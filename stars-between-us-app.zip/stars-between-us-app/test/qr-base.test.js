const test = require('node:test');
const assert = require('node:assert');
const { qrBase, firstLanIp } = require('../lib/qr-base');
test('PUBLIC_URL wins, trailing slash removed', () => {
  assert.strictEqual(qrBase({ publicUrl: 'https://x.example/', protocol: 'http', host: 'localhost:3000', lanIp: '192.168.0.5', port: 3000 }), 'https://x.example');
});
test('localhost is replaced by the network address', () => {
  assert.strictEqual(qrBase({ publicUrl: '', protocol: 'http', host: 'localhost:3000', lanIp: '192.168.0.5', port: 3000 }), 'http://192.168.0.5:3000');
});
test('a real host is kept', () => {
  assert.strictEqual(qrBase({ publicUrl: '', protocol: 'http', host: '192.168.0.5:3000', lanIp: '10.0.0.1', port: 3000 }), 'http://192.168.0.5:3000');
});
test('firstLanIp skips internal addresses', () => {
  assert.strictEqual(firstLanIp({ lo: [{ family: 'IPv4', internal: true, address: '127.0.0.1' }], wifi: [{ family: 'IPv4', internal: false, address: '192.168.1.9' }] }), '192.168.1.9');
});
