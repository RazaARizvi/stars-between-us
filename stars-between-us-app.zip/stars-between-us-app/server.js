// Stars Between Us: server.
// Serves the pages, receives stars from the iPad, sends them to every screen,
// and saves them to data/stars.json so the sky survives a restart.
//
//   /          the two buttons: iPad or Screen
//   /ipad      the iPad app (colours, place the star, join a star)
//   /screen    the big screen on the HDMI cable (with sound)
//   /sky       the same sky on a visitor's phone, from the QR code (silent)
const http = require('http');
const fs = require('fs');
const os = require('os');
const { qrBase, firstLanIp } = require('./lib/qr-base');
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const { Server } = require('socket.io');
const { COLOURS } = require('./config/colours');
const { makeStar } = require('./public/js/stars-lib.js');

const PORT = process.env.PORT || 3000;
const PUBLIC_URL = process.env.PUBLIC_URL || '';          // the address visitors can reach, for the QR code
const ADMIN_TOKEN = process.env.ADMIN_TOKEN || '';        // set it to allow POST /api/reset
const DATA_FILE = path.join(__dirname, 'data', 'stars.json');
const VALID_KEYS = COLOURS.map((c) => c.key);

const app = express();
const server = http.createServer(app);
const io = new Server(server);

let stars = [];
try { stars = JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); } catch (e) { stars = []; }

function saveStars() {
  fs.mkdirSync(path.dirname(DATA_FILE), { recursive: true });
  const tmp = DATA_FILE + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(stars, null, 2));
  fs.renameSync(tmp, DATA_FILE);                           // a crash never leaves a half-written file
}

// --- API ---
app.get('/api/colours', (req, res) => res.json(COLOURS));
app.get('/api/stars', (req, res) => res.json(stars));

// Audio files dropped into public/sounds/ (red.wav ... orange.wav, base.wav). The screen page loads what it finds here.
app.get('/api/sounds', (req, res) => {
  const names = [...VALID_KEYS, 'base'];
  const files = {};
  try {
    for (const f of fs.readdirSync(path.join(__dirname, 'public', 'sounds'))) {
      const m = /^([a-z]+)\.(wav|mp3|ogg|m4a|aac|flac)$/i.exec(f);
      if (m && names.includes(m[1].toLowerCase())) files[m[1].toLowerCase()] = '/sounds/' + f;
    }
  } catch (e) { /* no folder yet: the browser tones are used */ }
  res.json({ files });
});

// QR code for the phone viewer (/sky). Needs `npm install` (qrcode).
app.get('/api/qr.svg', async (req, res) => {
  try {
    const QRCode = require('qrcode');
    const base = qrBase({ publicUrl: PUBLIC_URL, protocol: req.protocol, host: req.get('host'), lanIp: firstLanIp(os.networkInterfaces()), port: PORT });
    res.type('image/svg+xml').send(await QRCode.toString(base + '/sky', { type: 'svg', margin: 1 }));
  } catch (e) {
    res.status(503).send('QR code not available');
  }
});

// Empty the sky before the workshop. Only if ADMIN_TOKEN is set:  curl -X POST -H "x-admin-token: ..." /api/reset
app.post('/api/reset', (req, res) => {
  if (!ADMIN_TOKEN || req.get('x-admin-token') !== ADMIN_TOKEN) return res.status(403).json({ error: 'forbidden' });
  stars = []; saveStars();
  io.emit('stars:init', stars);
  res.json({ ok: true });
});

// --- Pages ---
app.get('/sky', (req, res) => res.sendFile(path.join(__dirname, 'public', 'screen.html')));
app.use(express.static(path.join(__dirname, 'public'), { extensions: ['html'] }));

// --- Realtime ---
io.on('connection', (socket) => {
  socket.emit('stars:init', stars);                        // a new page gets the whole sky
  socket.on('star:add', (data) => {
    const star = makeStar(data, { validKeys: VALID_KEYS, stars, id: crypto.randomUUID(), now: Date.now() });
    if (!star) return;
    stars.push(star);
    try { saveStars(); } catch (e) { console.error('Could not save stars', e.message); }
    io.emit('star:added', star);                           // to everyone, including the iPad that sent it
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log('Stars Between Us on http://localhost:' + PORT);
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) for (const n of nets[name]) {
    if (n.family === 'IPv4' && !n.internal) {
      console.log('  iPad:   http://' + n.address + ':' + PORT + '/ipad');
      console.log('  Screen: http://' + n.address + ':' + PORT + '/screen');
    }
  }
});
