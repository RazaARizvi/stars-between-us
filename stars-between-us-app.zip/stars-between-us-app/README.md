# Stars Between Us: the whole app in one project

iPad app, big-screen sky, live sound, QR for phones. One server, three pages.

## Run it
1. Install Node.js (LTS).
2. In this folder: `npm install`, then `npm start`.
3. The terminal prints two addresses. Open the **iPad** one on the iPad and the **Screen** one on the laptop (same network, or host it online).
4. On the screen page press **Start sound** once.

Try it without Node: open `public/index.html` in Chrome. With no server the pages run in **demo mode** (stars stay in that browser; the iPad and the screen can be two tabs of the same browser).

## The pages
| Address | What it is |
| --- | --- |
| `/` | Two buttons: iPad and Screen |
| `/ipad` | Step 1 only the six colours (German title, English small), up to 4; the question cards are physical, on the table. Step 2 place the star in the sky. Step 3 choose the star to join (the sky suggests the one that shares the most colours). Step 4 the star is in the sky, next group. EN/DE toggle for the other texts. |
| `/screen` | The full sky for the HDMI cable, with sound, and the QR code in the top right corner. Keys: `f` full screen, `h` hide text, `1` / `2` sound rule, `m` mute. |
| `/sky` | The same sky for a visitor's phone (from the QR code). No sound. |

## Who changes what (each person has their own files)
| Who | Files |
| --- | --- |
| Sky and star look (shapes, colours of the sky, how lines look) | `public/js/common.js`, function `createSky()` and `drawStar()` |
| iPad look (layout, font, buttons, texts in EN and DE) | `public/ipad.html` (CSS at the top, texts in the `T` table) |
| Screen look (title, QR position, text on the big screen) | `public/screen.html` |
| Fonts and colours shared by all pages | `public/css/app.css` (top, `:root`) and the Google Fonts `<link>` at the top of each page |
| Music | drop audio files in `public/sounds/` (see `public/sounds/README.md`); rules in `public/js/sound.js` |
| Connection and saving | `server.js`, `public/js/stars-lib.js` (change only together) |

## Working together on GitHub
Upload this whole folder (`stars-between-us-app`) into the shared repository as it is (GitHub website: Add file, Upload files, drag the folder). It has its own `server.js` and `public/`, so it does not overwrite the files that are already in the repository. For now the repository holds two versions (the earlier one and this one); the team decides later which one stays as the official one, and what is copied across.
Everyone who edits must be a collaborator (repository Settings, Collaborators, write access). Then:
1. `git clone` the repository, open the folder `stars-between-us-app`, and `git pull` before you start each time.
2. Work in your own files (table above), so nobody edits the same lines.
3. Commit small, and `git push`. For bigger changes make a branch and open a pull request, and someone else looks before it is merged.
4. `data/` (the saved stars) and `node_modules/` are not in git. Each computer has its own.

## Where each colleague plugs in
- **Sky design:** `public/js/common.js`, function `createSky()`. It is one small interface (listed at the top of the file). Replace it with the new renderer and nothing else changes. The stars are drawn with eight points; the shape is in `drawStar()`.
- **Sound:** `public/js/sound.js`. The six tones are in `TONES` (placeholder: whole-tone scale on F). Use `StarSound.setTones({...})` or edit the table.
- **Colours:** the six colours live in `config/colours.js` (same shape as the repo's file) and the pages read them from `/api/colours`. (`QUESTIONS` in `public/js/common.js` is no longer used on the iPad, because the cards are physical.)
- **iPad look:** `public/ipad.html` (CSS at the top, texts in the `T` table, EN and DE).

## The star
`{ id, colours: ['red','blue','red'], x: 0..1, y: 0..1, linkedTo: id or null, timestamp }`
The iPad sends `star:add` with colours, x, y, linkedTo. The server checks it (`public/js/stars-lib.js`), adds id and timestamp, saves it to `data/stars.json` and sends `star:added` to every page. A new page gets `stars:init` with the whole sky. Stars that are already in the sky when a page opens do not sound.

## Sound: the open decision
The rule for a repeated colour is not fixed, so two are built. Press `1` or `2` on the screen page and listen.
1. **presence:** the more a colour appears in the whole sky, the more present its tone is (louder in each chime, picked more often by the background notes, and a low hum on the majority colour).
2. **layers:** a colour repeated inside one star adds layers to its tone (octave, fifth, quick octave).
Either way the loudness stays the same. Default: presence. When the team decides, the other one can be deleted.

## QR code: how it works and how to make it work at the venue
**What it does.** The big screen shows a QR code. A phone that scans it opens `/sky` and watches the constellation grow (silent). The code contains one web address, made by the server at `/api/qr.svg`.

**The one rule.** The address in the QR must be reachable *from the visitors' phones*. `localhost` is only the laptop itself, so it never works for phones. If the screen page is opened as `localhost`, the server replaces it with the laptop's address on the network (it prints this address as "Screen: http://192.168.x.x:3000/screen" when it starts). If you use a public address, set it with `PUBLIC_URL`.

**Three ways to do it.** Pick one before 5 December and test it with a real phone.

| | A. Our own Wi-Fi | B. Tunnel from the laptop | C. Hosted online |
| --- | --- | --- | --- |
| Idea | Laptop, iPad and phones are on the same Wi-Fi | The laptop runs the app and a tunnel gives it a public address | The app runs on an online server |
| Needs | A small router or a phone hotspot (not the venue guest Wi-Fi, which often blocks devices from seeing each other) | Internet at the venue for the laptop | Internet at the venue for laptop and iPad; an account on a hosting service |
| Visitors | First join our Wi-Fi (a Wi-Fi QR code helps), then scan | Scan with their own mobile data | Scan with their own mobile data |
| Stars saved | On the laptop | On the laptop | On the server (check that its disk is kept between restarts) |
| Risk | Visitors must change Wi-Fi: friction | The tunnel address changes each time you start it | Free plans sleep and can lose saved files |

How to run each:
- **A:** start the app (`npm start`), open the printed `Screen` address on the screen laptop. Leave `PUBLIC_URL` empty.
- **B:** start the app, then start a tunnel in a second terminal (for example `cloudflared tunnel --url http://localhost:3000`; it prints an `https://...` address). Stop the app, restart it with `PUBLIC_URL=https://that-address npm start` (on Windows PowerShell: `$env:PUBLIC_URL="https://that-address"; npm start`), and open that same address on the screen and the iPad.
- **C:** host the folder on any Node hosting service, set `PUBLIC_URL` to its address, open that address on the screen and the iPad.

Our suggestion: B for the workshop (the stars stay on our laptop, no accounts), A as the plan if the venue has no internet. This has not been tested yet; try it once at home with a phone on mobile data.

`ADMIN_TOKEN=secret` allows `POST /api/reset` (header `x-admin-token`) to empty the sky before the workshop.

## Fonts and look and feel
`DESIGN.md` is the one-page reference (fonts, the six colours, night colours, star rules). The font is set in one place, the top of `public/css/app.css`. For offline use see `public/fonts/README.md`. The font must be decided before the cards are printed.

## Sound files
`public/sounds/` is the drop-in folder: audio files named after the colours (and `base.wav` for a starting loop) are recognised without any code. The screen shows which files it found. How colours should alter a starting melody is still an open question for the team.

## Not included
The live Ableton path (`music.js`, `als_to_score.py`, `sky.html` from the team folder, MIDI to visual channels) is not part of this project. It needs `sky.js`, which was not in the folder.

## What was tested
- Unit tests for the star rules and the QR address rule: `npm test` (9 tests).
- In a real browser, in demo mode: the full iPad flow (card, colours, place, join, send), the star arriving on a second page with its line, both sound rules playing, and the phone page staying silent.
- **Not tested:** the server itself (`server.js`), the QR image and any tunnel or hosting, because Node packages could not be installed where this was built. They use standard Express and Socket.IO. Please run it once and tell us what the terminal says.
- German texts need a native check.

## Open decisions (owner)
| Decision | Who |
| --- | --- |
| Font (before printing the cards) | Typography |
| Sky design (based on the Mihika and Akshara presentation) | Sky designers |
| Same look on cards, iPad and sky (use `DESIGN.md`) | Everyone |
| Sound rule for repeated colours; how the starting melody is changed by the tones | Sound |
| Audio files into `public/sounds/` | Sound (Ableton) |
| QR route: A, B or C | Laura and whoever runs the laptop |
| Merge with the earlier repository version | Everyone, after the upload |
