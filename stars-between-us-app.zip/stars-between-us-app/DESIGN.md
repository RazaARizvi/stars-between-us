# Look and feel: one system for cards, iPad, screen and sky

The cards, the iPad and the big screen must look like one piece. This page is the single reference. Everything here is read from two files, so a change in one place changes every page:
- `public/css/app.css` (night colours, fonts, buttons)
- `config/colours.js` (the six colours and their words)

## Fonts (decision needed before the cards are printed)
Placeholder for now: **Bricolage Grotesque** (titles and texts) and **DM Mono** (small labels). Both are free and open (SIL Open Font Licence), so they can also be used on printed cards and posters.
To change the font: edit the `@import` line and the two `--display` / `--mono` lines at the top of `public/css/app.css`. Nothing else.
Print the cards with the same font as the iPad. Pick the font first, then print.

## The six colours (words: German large, English small)
| Key | Hex | Deutsch | English |
| --- | --- | --- | --- |
| red | `#ff6b5e` | Wärme | Warmth |
| yellow | `#ffd45e` | Licht | Light |
| blue | `#5e9bff` | Ruhe | Calm |
| green | `#5ee08f` | Wachsen | Growth |
| purple | `#b17bff` | Erinnerung | Memory |
| orange | `#ff9a4d` | Gesellschaft | Company |

Colours on screen (light) and on paper (ink) never match exactly. Print one test card and hold it next to the real ribbons before printing all of them.

## Night sky
| Use | Hex |
| --- | --- |
| Night (background) | `#0a0f1e` |
| Panel | `#111a33` |
| Text | `#e8ecf8` |
| Muted text | `#97a3c6` |
| Frost (buttons, lines) | `#d3e2ff` |

## Star
Eight points (the Fröbel star seen from above). A star with more colours is a little bigger (radius grows with the number of colours). A star that joined another one is drawn with a thin line to it. The shape is in `drawStar()` in `public/js/common.js`.

## Rules so everything matches
- German title first and large, English small below, on cards, iPad and screen.
- Only the six colours above for stars. Night colours for everything else.
- Buttons: large (minimum 56 px high) so they work with fingers on the iPad.
- The sky designers change `createSky()` / `drawStar()`; the iPad and screen pages use the same sky, so they follow automatically.
