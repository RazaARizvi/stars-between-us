// The six colours. One source of truth for the server; the pages read it from /api/colours.
// Same shape as config/colours.js in the GitHub repo (key, hex, de, en, melody).
module.exports.COLOURS = [
  { key: 'red',    hex: '#ff6b5e', de: 'Wärme',        en: 'Warmth',  melody: 'melody-red' },
  { key: 'yellow', hex: '#ffd45e', de: 'Licht',        en: 'Light',   melody: 'melody-yellow' },
  { key: 'blue',   hex: '#5e9bff', de: 'Ruhe',         en: 'Calm',    melody: 'melody-blue' },
  { key: 'green',  hex: '#5ee08f', de: 'Wachsen',      en: 'Growth',  melody: 'melody-green' },
  { key: 'purple', hex: '#b17bff', de: 'Erinnerung',   en: 'Memory',  melody: 'melody-purple' },
  { key: 'orange', hex: '#ff9a4d', de: 'Gesellschaft', en: 'Company', melody: 'melody-orange' }
];
